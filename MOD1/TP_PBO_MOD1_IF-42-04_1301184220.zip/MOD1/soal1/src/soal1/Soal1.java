/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package soal1;

/**
 *
 * @author Afif Raihan
 */
public class Soal1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] isi = new int[4][10];
        isi[0][0] = 2;
        isi[0][1] = 4;
        isi[0][2] = 6;
        
        
        isi[1][0] = 1;
        isi[1][1] = 3;
        isi[1][2] = 5;
        isi[1][3] = 7;
        isi[1][4] = 9;
        isi[1][5] = 11;
        isi[1][6] = 13;
        
        isi[2][0] = 0;
        
        isi[3][0] = 1;
        isi[3][1] = 2;
        isi[3][2] = 3;
        isi[3][3] = 4;
        isi[3][4] = 5;
        isi[3][5] = 6;
        isi[3][6] = 7;
        isi[3][7] = 8;
        isi[3][8] = 9;
        isi[3][9] = 10;
        
        System.out.print(isi[0][0] + " ");
        System.out.print(isi[0][1] + " ");
        System.out.println(isi[0][2] + " ");
        
        System.out.print(isi[1][0] + " ");
        System.out.print(isi[1][1] + " ");
        System.out.print(isi[1][2] + " ");
        System.out.print(isi[1][3] + " ");
        System.out.print(isi[1][4] + " ");
        System.out.print(isi[1][5] + " ");
        System.out.println(isi[1][6] + " ");
        
        System.out.println(isi[2][0]);
        
        System.out.print(isi[3][0] + " ");
        System.out.print(isi[3][1] + " ");
        System.out.print(isi[3][2] + " ");
        System.out.print(isi[3][3] + " ");
        System.out.print(isi[3][4] + " ");
        System.out.print(isi[3][5] + " ");
        System.out.print(isi[3][6] + " ");
        System.out.print(isi[3][7] + " ");
        System.out.print(isi[3][8] + " ");
        System.out.println(isi[3][9]);
        
    }
}
